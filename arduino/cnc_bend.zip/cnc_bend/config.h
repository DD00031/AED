#pragma once

// --- Config --- 

// --- Pin Declarations ---
// Doorvoer = X
// Torsie = Y
// Buiging = Z
// Stage = A
// (CHANGE THE PINS TO MATCH THE CORRECT ONES FROM THE README!)
const int transportStep = A4;
const int transportDir = A3;
const int torsionStep = 3;
const int torsionDir = 6;
const int bendingStep = 4;
const int bendingDir = 7;
const int stageStep = 2;
const int stageDir = 5;

const int transport[] = {transportStep, transportDir};
const int torsion[] = {torsionStep, torsionDir};
const int bending[] = {bendingStep, bendingDir};
const int stage[] = {stageStep, stageDir};

// --- Dimension Declarations ---
// Transport
const int rWheel = 43; //mm
// Bending

// Torsion
