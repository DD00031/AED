#include "config.h"

void initStage(){
  pinMode(stageStep, OUTPUT);
  pinMode(stageDir, OUTPUT);
}

void moveStage(stageDist){
  Serial.println("Stage placeholder, entered distance: ");
}