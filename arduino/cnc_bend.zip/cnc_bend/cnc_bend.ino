#include "config.h"

void setup() {
  Serial.begin(9600);
  initTransport();
  initTorsion();
  initBending();

  Serial.println("Ready.");
//  transportStrip(100);
//  Serial.println("Done.");
}

void loop() {
  handleSerialCommands();
}